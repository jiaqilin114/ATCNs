import numpy as np
import matplotlib.pyplot as plt

def Draw_flow(data_path):
    # 读取.npy文件
    data = np.load(data_path, allow_pickle=True)
    print(data)
    # 将数组内绝对值大于10的值置零
    #data[np.abs(data) > 10] = 0
    # 获取数组数据
    array_data = data[:, :, :]
    # 打印数组数据
    print(array_data)
    # 可视化数据（彩色图像）
    plt.imshow(array_data[:, :, 0], cmap='viridis')
    plt.colorbar()
    plt.show()

def visualize_and_save_image(data_file, output_image):
    # 加载.npy文件数据
    data = np.load(data_file)
    # 创建图像
    plt.imshow(data[:, :, 0], cmap='viridis')  # 假设选择第一个通道进行可视化
    plt.colorbar()
    # 保存图像为图片文件
    plt.savefig(output_image)
    # 显示图像（可选）
    plt.show()



def main():
    data_path = "Data/202101_12_40N110E_10N140E_361_361/train/hycom_6H_0/down_hycom_0.08_40N110E_10N140E_2021_01_12_773.npy"
    Draw_flow(data_path)

    #data_path1 = "ekman/ekman_flow.npy"
    #Draw_flow(data_path1)

    # 将可视化场图保存为图片
    #data_file = 'Data/filtered_data.npy'  # 修改为你的.npy文件路径
    #output_image = 'output_image.png'     # 修改为输出图片的路径

    #visualize_and_save_image(data_file, output_image)


if __name__ == "__main__":
    main()
