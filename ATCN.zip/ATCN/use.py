import tensorflow as tf
import numpy as np

def load_and_run_model(input_file, output_file, model_meta_file, model_checkpoint_file):
    # 创建 TensorFlow 会话
    sess = tf.Session()

    # 加载 .meta 文件
    saver = tf.train.import_meta_graph(model_meta_file)

    # 恢复模型参数
    saver.restore(sess, model_checkpoint_file)

    # 获取模型的输入和输出张量名称
    graph = tf.get_default_graph()
    input_tensor = graph.get_tensor_by_name('input:0')  # 假设输入张量名称是 'input:0'
    output_tensor = graph.get_tensor_by_name('output:0')  # 假设输出张量名称是 'output:0'

    # 加载输入数据
    input_data = np.load(input_file)

    # 执行推理
    output_data = sess.run(output_tensor, feed_dict={input_tensor: input_data})

    # 保存输出数据
    np.save(output_file, output_data)

    # 关闭 TensorFlow 会话
    sess.close()

def main():
    input_file = 'path/to/input.npy'
    output_file = 'path/to/output.npy'
    model_meta_file = 'save/models/WindPred9.ckpt.meta'
    model_checkpoint_file = 'save/models/230914/checkpoint'

    load_and_run_model(input_file, output_file, model_meta_file, model_checkpoint_file)

if __name__ == '__main__':
    main()
