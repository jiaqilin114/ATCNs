import os
import numpy as np

def get_dir(directory):
    """
    Creates the given directory if it does not exist.

    @param directory: The path to the directory.
    @return: The path to the directory.
    """

    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory

save_name = '240301_WIND_ATCN'
save_dir = '../save/'

train_save_dir = get_dir(os.path.join(save_dir, 'train/', save_name))
test_save_dir = get_dir(os.path.join(save_dir, 'test/', save_name))
save_models_dir = get_dir(os.path.join(save_dir, 'models/', save_name))
loss_save_dir = get_dir(os.path.join(save_dir,'loss/', save_name))

train_original_dir = '../../Data/WindData_40N110E_10N140E_241_2021/train/ForecastData/'
train_revised_dir = '../../Data/WindData_40N110E_10N140E_241_2021/train/ReanalysisData/'
test_original_dir = '../../Data/WindData_40N110E_10N140E_241_2021/test/ForecastData/'
test_revised_dir = '../../Data/WindData_40N110E_10N140E_241_2021/test/ReanalysisData/'

data_height =  241 #jql latitude resolution:0.08du
data_width =  241#jql longitude 0.08du

